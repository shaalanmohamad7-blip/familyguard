import Link from "next/link";
import { redirect } from "next/navigation";
import { isLocale, defaultLocale, type Locale } from "@/i18n/config";
import { requireParentContext } from "@/lib/parentSession";
import { isAdminSession } from "@/lib/admin";
import { prisma } from "@/lib/prisma";
import AdminApprovals from "@/components/AdminApprovals";

export const dynamic = "force-dynamic";

export default async function AdminPage({
  params,
}: {
  params: { locale: string };
}) {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  const ar = locale === "ar";

  const ctx = await requireParentContext();
  if (!ctx) {
    redirect(`/${locale}/signin`);
  }
  if (!(await isAdminSession())) {
    redirect(`/${locale}/dashboard`);
  }

  const users = await prisma.user.findMany({
    where: { status: "PENDING" },
    orderBy: { createdAt: "asc" },
    select: {
      id: true,
      name: true,
      email: true,
      createdAt: true,
      memberships: { select: { family: { select: { name: true } } }, take: 1 },
    },
  });

  const initialUsers = users.map((u) => ({
    id: u.id,
    name: u.name,
    email: u.email,
    createdAt: u.createdAt.toISOString(),
    familyName: u.memberships[0]?.family.name ?? null,
  }));

  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <Link href={`/${locale}/dashboard`} className="text-sm font-semibold text-brand-700">
        {ar ? "→ العودة للوحة التحكم" : "← Back to dashboard"}
      </Link>
      <h1 className="mt-4 text-2xl font-extrabold text-slate-900">
        {ar ? "الموافقة على الحسابات" : "Account approvals"}
      </h1>
      <p className="mt-2 text-sm text-slate-600">
        {ar
          ? "هذه حسابات أولياء الأمور الجديدة التي تنتظر موافقتك. الموافقة تفعّل الحساب، والرفض يمنع الدخول."
          : "These new parent accounts are waiting for your approval. Approving activates the account; rejecting blocks access."}
      </p>

      <div className="mt-8">
        <AdminApprovals initialUsers={initialUsers} ar={ar} />
      </div>
    </div>
  );
}
