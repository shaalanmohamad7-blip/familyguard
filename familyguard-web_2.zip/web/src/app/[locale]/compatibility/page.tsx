import { isLocale, defaultLocale, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/getDictionary";

const FEATURE_ROWS = [
  { key: "location", android: true, ios: true },
  { key: "geofence", android: true, ios: true },
  { key: "sos", android: true, ios: true },
  { key: "screenTime", android: true, ios: false },
  { key: "limits", android: true, ios: false },
  { key: "status", android: true, ios: false },
] as const;

export default function CompatibilityPage({ params }: { params: { locale: string } }) {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  const dict = getDictionary(locale);
  const t = dict.compatibility;
  const featuresDict = dict.features;

  const rowLabel: Record<string, string> = {
    location: featuresDict.location.title,
    geofence: featuresDict.geofence.title,
    sos: featuresDict.sos.title,
    screenTime: featuresDict.screenTime.title,
    limits: featuresDict.limits.title,
    status: dict.dashboard.overview.permissionsTitle,
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-16">
      <div className="mx-auto max-w-2xl text-center">
        <h1 className="text-3xl font-extrabold text-slate-900">{t.title}</h1>
        <p className="mt-3 text-slate-600">{t.subtitle}</p>
      </div>

      <div className="mt-12 grid gap-6 sm:grid-cols-2">
        <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-6">
          <h2 className="font-bold text-emerald-900">{t.androidTitle}</h2>
          <p className="mt-2 text-sm text-emerald-800">{t.androidBody}</p>
          <ul className="mt-4 space-y-2 text-sm text-emerald-900">
            {t.androidList.map((item) => (
              <li key={item} className="flex gap-2">
                <span>&#10003;</span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-slate-50 p-6">
          <h2 className="font-bold text-slate-900">{t.iosTitle}</h2>
          <p className="mt-2 text-sm text-slate-700">{t.iosBody}</p>
          <ul className="mt-4 space-y-2 text-sm text-slate-800">
            {t.iosList.map((item) => (
              <li key={item} className="flex gap-2">
                <span>&#10003;</span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="mt-8 rounded-2xl border border-amber-300 bg-amber-50 p-6">
        <h3 className="font-semibold text-amber-900">{t.iosLimitTitle}</h3>
        <p className="mt-2 text-sm text-amber-900">{t.iosLimitBody}</p>
      </div>

      <div className="mt-12">
        <h2 className="mb-4 text-lg font-bold text-slate-900">{t.tableTitle}</h2>
        <div className="overflow-hidden rounded-2xl border border-slate-200">
          <table className="w-full text-start text-sm">
            <thead className="bg-slate-50 text-slate-600">
              <tr>
                <th className="px-4 py-3 text-start font-semibold">{t.tableFeature}</th>
                <th className="px-4 py-3 text-start font-semibold">{t.tableAndroid}</th>
                <th className="px-4 py-3 text-start font-semibold">{t.tableIos}</th>
              </tr>
            </thead>
            <tbody>
              {FEATURE_ROWS.map((row) => (
                <tr key={row.key} className="border-t border-slate-100">
                  <td className="px-4 py-3 font-medium text-slate-900">{rowLabel[row.key]}</td>
                  <td className="px-4 py-3">
                    <span className={row.android ? "text-emerald-700" : "text-slate-400"}>
                      {row.android ? t.yes : t.no}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={row.ios ? "text-emerald-700" : "text-slate-400"}>
                      {row.ios ? t.yes : t.no}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
