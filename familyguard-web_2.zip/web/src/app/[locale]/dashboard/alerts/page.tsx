import { redirect } from "next/navigation";
import { isLocale, defaultLocale, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/getDictionary";
import { requireParentContext } from "@/lib/parentSession";
import { prisma } from "@/lib/prisma";
import AlertsClient from "@/components/AlertsClient";

export const dynamic = "force-dynamic";

export default async function AlertsPage({ params }: { params: { locale: string } }) {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  const dict = getDictionary(locale);

  const ctx = await requireParentContext();
  if (!ctx) redirect(`/${locale}/signin`);

  const alerts = await prisma.alert.findMany({
    where: { familyId: ctx!.familyId },
    orderBy: [{ createdAt: "desc" }],
    take: 200,
    include: { device: { select: { id: true, label: true } } },
  });

  const sorted = [...alerts].sort((a, b) => {
    const aUrgent = a.type === "SOS" && !a.acknowledgedAt;
    const bUrgent = b.type === "SOS" && !b.acknowledgedAt;
    if (aUrgent !== bUrgent) return aUrgent ? -1 : 1;
    const aAck = a.acknowledgedAt ? 1 : 0;
    const bAck = b.acknowledgedAt ? 1 : 0;
    if (aAck !== bAck) return aAck - bAck;
    return b.createdAt.getTime() - a.createdAt.getTime();
  });

  const serializable = sorted.map((a) => ({
    id: a.id,
    type: a.type,
    createdAt: a.createdAt.toISOString(),
    acknowledgedAt: a.acknowledgedAt ? a.acknowledgedAt.toISOString() : null,
    device: a.device,
    payload: a.payload as unknown as Record<string, unknown>,
  }));

  return (
    <div>
      <h1 className="mb-6 text-2xl font-extrabold text-slate-900">{dict.dashboard.alerts.title}</h1>
      <AlertsClient initial={serializable} t={dict.dashboard.alerts} locale={locale} />
    </div>
  );
}
