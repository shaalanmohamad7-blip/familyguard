import { notFound, redirect } from "next/navigation";
import Link from "next/link";
import { isLocale, defaultLocale, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/getDictionary";
import { requireParentContext, getFamilyDevice } from "@/lib/parentSession";
import { prisma } from "@/lib/prisma";
import UsageBarChart from "@/components/UsageBarChart";
import { UnlinkDeviceButton, LimitRuleForm } from "@/components/DeviceDetailActions";

export const dynamic = "force-dynamic";

export default async function DeviceDetailPage({
  params,
}: {
  params: { locale: string; id: string };
}) {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  const dict = getDictionary(locale);
  const tDevice = dict.dashboard.device;
  const tUsage = dict.dashboard.usage;
  const tOverview = dict.dashboard.overview;

  const ctx = await requireParentContext();
  if (!ctx) redirect(`/${locale}/signin`);

  const device = await getFamilyDevice(ctx!.familyId, params.id);
  if (!device) notFound();

  const limitRule = await prisma.limitRule.findUnique({ where: { deviceId: device.id } });

  const since = new Date();
  since.setDate(since.getDate() - 6);
  since.setHours(0, 0, 0, 0);

  const usage = await prisma.usageRecord.findMany({
    where: { deviceId: device.id, date: { gte: since } },
  });

  const dayFormatter = new Intl.DateTimeFormat(locale === "ar" ? "ar" : "en-US", {
    weekday: "short",
  });

  const dayBuckets: { label: string; minutes: number; key: string }[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    dayBuckets.push({ label: dayFormatter.format(d), minutes: 0, key });
  }
  for (const u of usage) {
    const key = u.date.toISOString().slice(0, 10);
    const bucket = dayBuckets.find((b) => b.key === key);
    if (bucket) bucket.minutes += u.minutes;
  }

  const appTotals = new Map<string, number>();
  for (const u of usage) {
    appTotals.set(u.appLabel, (appTotals.get(u.appLabel) ?? 0) + u.minutes);
  }
  const topApps = [...appTotals.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([label, minutes]) => ({ label, minutes }));

  const perms = (device.permissions as unknown as Record<string, boolean>) || {};
  const isAndroid = device.platform === "ANDROID";

  return (
    <div>
      <Link href={`/${locale}/dashboard`} className="text-sm font-semibold text-brand-700 hover:underline">
        &larr; {tDevice.backToOverview}
      </Link>

      <div className="mt-4 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">{device.label}</h1>
          <p className="text-sm text-slate-500">
            {device.platform} &middot; {tOverview.status}: {device.status}
          </p>
        </div>
        <UnlinkDeviceButton deviceId={device.id} locale={locale} t={tDevice} />
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-4">
        <div className="rounded-xl border border-slate-200 p-4">
          <p className="text-xs text-slate-400">{tOverview.battery}</p>
          <p className="text-lg font-semibold text-slate-900">
            {device.batteryPct != null ? `${device.batteryPct}%` : "—"}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 p-4">
          <p className="text-xs text-slate-400">{tOverview.lastSeen}</p>
          <p className="text-sm font-semibold text-slate-900">
            {device.lastSeenAt ? new Date(device.lastSeenAt).toLocaleString() : tOverview.neverSeen}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 p-4">
          <p className="text-xs text-slate-400">{tOverview.locationFg}</p>
          <p className="text-sm font-semibold text-slate-900">
            {perms.locationFg ? tOverview.granted : tOverview.notGranted}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 p-4">
          <p className="text-xs text-slate-400">{tOverview.locationBg}</p>
          <p className="text-sm font-semibold text-slate-900">
            {perms.locationBg ? tOverview.granted : tOverview.notGranted}
          </p>
        </div>
      </div>

      <div className="mt-10">
        <div className="mb-4 flex items-center gap-3">
          <h2 className="text-lg font-bold text-slate-900">{tUsage.title}</h2>
          <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-500">
            {tUsage.androidOnly}
          </span>
        </div>

        {!isAndroid ? (
          <p className="text-sm text-slate-500">{tUsage.androidOnly}</p>
        ) : usage.length === 0 ? (
          <p className="text-sm text-slate-500">{tUsage.noUsageData}</p>
        ) : (
          <div className="grid gap-8 lg:grid-cols-2">
            <div className="rounded-2xl border border-slate-200 p-5">
              <h3 className="mb-3 text-sm font-semibold text-slate-700">{tUsage.last7days}</h3>
              <UsageBarChart
                data={dayBuckets.map((b) => ({ label: b.label, minutes: b.minutes }))}
                unitLabel={tUsage.minutes}
              />
            </div>
            <div className="rounded-2xl border border-slate-200 p-5">
              <h3 className="mb-3 text-sm font-semibold text-slate-700">{tUsage.topApps}</h3>
              <ul className="space-y-2">
                {topApps.map((app) => (
                  <li key={app.label} className="flex items-center justify-between text-sm">
                    <span className="text-slate-700">{app.label}</span>
                    <span className="font-medium text-slate-500">
                      {app.minutes} {tUsage.minutes}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}

        {isAndroid && (
          <div className="mt-6 rounded-2xl border border-slate-200 p-5">
            <h3 className="mb-4 text-sm font-semibold text-slate-700">{tUsage.limitsTitle}</h3>
            <LimitRuleForm deviceId={device.id} initial={limitRule} t={tUsage} />
          </div>
        )}
      </div>
    </div>
  );
}
