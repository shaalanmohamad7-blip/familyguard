import { redirect } from "next/navigation";
import { isLocale, defaultLocale, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/getDictionary";
import { requireParentContext } from "@/lib/parentSession";
import { prisma } from "@/lib/prisma";
import GeofencesClient from "@/components/GeofencesClient";

export const dynamic = "force-dynamic";

export default async function GeofencesPage({ params }: { params: { locale: string } }) {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  const dict = getDictionary(locale);

  const ctx = await requireParentContext();
  if (!ctx) redirect(`/${locale}/signin`);

  const geofences = await prisma.geofence.findMany({
    where: { familyId: ctx!.familyId },
    orderBy: { name: "asc" },
  });

  return <GeofencesClient initial={geofences} t={dict.dashboard.geofences} />;
}
