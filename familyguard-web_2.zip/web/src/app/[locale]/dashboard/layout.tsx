import Link from "next/link";
import { redirect } from "next/navigation";
import { isLocale, defaultLocale, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/getDictionary";
import { requireParentContext } from "@/lib/parentSession";
import { isAdminEmail } from "@/lib/admin";
import { prisma } from "@/lib/prisma";
import DashboardNav from "@/components/DashboardNav";

export const dynamic = "force-dynamic";

export default async function DashboardLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: { locale: string };
}) {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  const dict = getDictionary(locale);
  const ar = locale === "ar";

  const ctx = await requireParentContext();
  if (!ctx) {
    redirect(`/${locale}/signin`);
  }

  const user = await prisma.user.findUnique({
    where: { id: ctx!.userId },
    select: { status: true, email: true, name: true },
  });

  const isAdmin = isAdminEmail(user?.email);

  // Accounts that the owner has not approved yet cannot use the dashboard.
  if (user?.status !== "ACTIVE" && !isAdmin) {
    const rejected = user?.status === "REJECTED";
    return (
      <div className="mx-auto max-w-lg px-4 py-20 text-center">
        <div className="mx-auto mb-6 flex h-14 w-14 items-center justify-center rounded-full bg-amber-100 text-2xl">
          {rejected ? "⛔" : "⏳"}
        </div>
        <h1 className="text-xl font-extrabold text-slate-900">
          {rejected
            ? ar ? "لم تتم الموافقة على حسابك" : "Your account was not approved"
            : ar ? "حسابك قيد المراجعة" : "Your account is pending review"}
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-slate-600">
          {rejected
            ? ar
              ? "عذرًا، لم تتم الموافقة على هذا الحساب. إذا تعتقد أن هناك خطأ، تواصل مع المسؤول."
              : "Sorry, this account was not approved. If you think this is a mistake, contact the administrator."
            : ar
              ? "شكرًا لتسجيلك. سيقوم المسؤول بمراجعة حسابك وتفعيله قريبًا. حاول تسجيل الدخول لاحقًا."
              : "Thanks for signing up. An administrator will review and activate your account soon. Please try signing in again later."}
        </p>
        <Link
          href={`/${locale}`}
          className="mt-8 inline-block rounded-full bg-brand-600 px-5 py-2 text-sm font-semibold text-white hover:bg-brand-700"
        >
          {ar ? "العودة للرئيسية" : "Back to home"}
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6 px-4 py-8 sm:flex-row">
      <DashboardNav locale={locale} dict={dict} />
      <div className="min-w-0 flex-1">
        {isAdmin && (
          <Link
            href={`/${locale}/admin`}
            className="mb-4 inline-flex items-center gap-2 rounded-lg border border-brand-200 bg-brand-50 px-4 py-2 text-sm font-semibold text-brand-700 hover:bg-brand-100"
          >
            {ar ? "لوحة المشرف — الموافقة على الحسابات" : "Admin panel — approve accounts"}
          </Link>
        )}
        {children}
      </div>
    </div>
  );
}
