import { redirect } from "next/navigation";
import { isLocale, defaultLocale, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/getDictionary";
import { requireParentContext } from "@/lib/parentSession";
import { prisma } from "@/lib/prisma";
import MapPageClient from "@/components/MapPageClient";

export const dynamic = "force-dynamic";

export default async function MapPage({ params }: { params: { locale: string } }) {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  const dict = getDictionary(locale);

  const ctx = await requireParentContext();
  if (!ctx) redirect(`/${locale}/signin`);

  const devices = await prisma.device.findMany({
    where: { familyId: ctx!.familyId, status: { not: "REVOKED" } },
    orderBy: { pairedAt: "asc" },
    select: { id: true, label: true },
  });

  const geofences = await prisma.geofence.findMany({
    where: { familyId: ctx!.familyId },
    select: { id: true, name: true, lat: true, lng: true, radiusM: true },
  });

  return <MapPageClient devices={devices} geofences={geofences} dict={dict} locale={locale} />;
}
