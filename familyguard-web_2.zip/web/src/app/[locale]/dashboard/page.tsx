import Link from "next/link";
import { redirect } from "next/navigation";
import { isLocale, defaultLocale, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/getDictionary";
import { requireParentContext } from "@/lib/parentSession";
import { prisma } from "@/lib/prisma";
import PairDeviceModal from "@/components/PairDeviceModal";

export const dynamic = "force-dynamic";

function timeAgo(date: Date | null, locale: Locale, neverLabel: string): string {
  if (!date) return neverLabel;
  return date.toLocaleString(locale === "ar" ? "ar" : "en-US", {
    dateStyle: "medium",
    timeStyle: "short",
  });
}

export default async function DashboardOverviewPage({
  params,
}: {
  params: { locale: string };
}) {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  const dict = getDictionary(locale);
  const t = dict.dashboard.overview;

  const ctx = await requireParentContext();
  if (!ctx) redirect(`/${locale}/signin`);

  const devices = await prisma.device.findMany({
    where: { familyId: ctx!.familyId },
    orderBy: { pairedAt: "asc" },
  });

  const statusLabel: Record<string, string> = {
    ACTIVE: t.active,
    OFFLINE: t.offline,
    REVOKED: t.revoked,
  };
  const statusColor: Record<string, string> = {
    ACTIVE: "bg-emerald-100 text-emerald-800",
    OFFLINE: "bg-slate-200 text-slate-600",
    REVOKED: "bg-red-100 text-red-700",
  };

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-extrabold text-slate-900">{t.title}</h1>
        <PairDeviceModal t={t} />
      </div>

      {devices.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 p-10 text-center text-slate-500">
          {t.noDevices}
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {devices.map((device) => {
            const perms = (device.permissions as unknown as Record<string, boolean>) || {};
            return (
              <div key={device.id} className="rounded-2xl border border-slate-200 p-5">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="font-semibold text-slate-900">{device.label}</h3>
                    <p className="text-xs uppercase tracking-wide text-slate-400">
                      {device.platform}
                    </p>
                  </div>
                  <span
                    className={`rounded-full px-2.5 py-1 text-xs font-semibold ${
                      statusColor[device.status] ?? "bg-slate-100 text-slate-600"
                    }`}
                  >
                    {statusLabel[device.status] ?? device.status}
                  </span>
                </div>

                <dl className="mt-4 grid grid-cols-2 gap-2 text-sm text-slate-600">
                  <div>
                    <dt className="text-xs text-slate-400">{t.battery}</dt>
                    <dd>{device.batteryPct != null ? `${device.batteryPct}%` : "—"}</dd>
                  </div>
                  <div>
                    <dt className="text-xs text-slate-400">{t.lastSeen}</dt>
                    <dd>{timeAgo(device.lastSeenAt, locale, t.neverSeen)}</dd>
                  </div>
                </dl>

                <div className="mt-4">
                  <p className="mb-1.5 text-xs font-semibold text-slate-500">
                    {t.permissionsTitle}
                  </p>
                  <div className="flex flex-wrap gap-1.5 text-xs">
                    {[
                      [t.locationFg, perms.locationFg],
                      [t.locationBg, perms.locationBg],
                      [t.usageAccess, perms.usageAccess],
                      [t.notifications, perms.notifications],
                    ].map(([label, granted]) => (
                      <span
                        key={label as string}
                        className={`rounded-full px-2 py-1 ${
                          granted
                            ? "bg-emerald-50 text-emerald-700"
                            : "bg-slate-100 text-slate-500"
                        }`}
                      >
                        {label} {granted ? "✓" : "–"}
                      </span>
                    ))}
                  </div>
                </div>

                <Link
                  href={`/${locale}/dashboard/devices/${device.id}`}
                  className="mt-5 inline-block text-sm font-semibold text-brand-700 hover:underline"
                >
                  {t.viewDevice} &rarr;
                </Link>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
