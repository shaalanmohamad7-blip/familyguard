import { redirect } from "next/navigation";
import { isLocale, defaultLocale, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/getDictionary";
import { requireParentContext } from "@/lib/parentSession";
import { prisma } from "@/lib/prisma";
import { UnlinkDeviceButton } from "@/components/DeviceDetailActions";
import DeleteFamilyData from "@/components/DeleteFamilyData";

export const dynamic = "force-dynamic";

export default async function SettingsPage({ params }: { params: { locale: string } }) {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  const dict = getDictionary(locale);
  const t = dict.dashboard.settings;
  const tDevice = dict.dashboard.device;

  const ctx = await requireParentContext();
  if (!ctx) redirect(`/${locale}/signin`);

  const devices = await prisma.device.findMany({
    where: { familyId: ctx!.familyId, status: { not: "REVOKED" } },
    orderBy: { pairedAt: "asc" },
  });

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-extrabold text-slate-900">{t.title}</h1>

      <section className="rounded-2xl border border-slate-200 p-5">
        <h2 className="font-semibold text-slate-900">{t.planTitle}</h2>
        <p className="mt-1 text-sm text-slate-600">{t.planBody}</p>
        <div className="mt-4 flex items-center justify-between rounded-xl bg-slate-50 px-4 py-3">
          <span className="text-sm font-medium text-slate-700">{t.currentPlan}: Family</span>
          <button className="rounded-full border border-slate-300 px-3 py-1.5 text-xs font-semibold text-slate-600">
            {t.changePlan}
          </button>
        </div>
      </section>

      <section className="rounded-2xl border border-slate-200 p-5">
        <h2 className="mb-4 font-semibold text-slate-900">{t.devicesTitle}</h2>
        {devices.length === 0 ? (
          <p className="text-sm text-slate-500">{dict.dashboard.overview.noDevices}</p>
        ) : (
          <div className="space-y-3">
            {devices.map((d) => (
              <div
                key={d.id}
                className="flex items-center justify-between rounded-xl border border-slate-100 px-4 py-3"
              >
                <div>
                  <p className="text-sm font-semibold text-slate-800">{d.label}</p>
                  <p className="text-xs text-slate-400">{d.platform}</p>
                </div>
                <UnlinkDeviceButton
                  deviceId={d.id}
                  locale={locale}
                  t={tDevice}
                  redirectToOverview={false}
                />
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="rounded-2xl border border-amber-200 bg-amber-50 p-5">
        <h2 className="font-semibold text-amber-900">{t.noticeTitle}</h2>
        <p className="mt-1 text-sm text-amber-800">{t.noticeBody}</p>
      </section>

      <DeleteFamilyData locale={locale} t={t} />
    </div>
  );
}
