import { isLocale, defaultLocale, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/getDictionary";

export default function FaqPage({ params }: { params: { locale: string } }) {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  const dict = getDictionary(locale);
  const t = dict.faq;

  const qas: [string, string][] = [
    [t.q1, t.a1],
    [t.q2, t.a2],
    [t.q3, t.a3],
    [t.q4, t.a4],
    [t.q5, t.a5],
    [t.q6, t.a6],
    [t.q7, t.a7],
    [t.q8, t.a8],
  ];

  return (
    <div className="mx-auto max-w-3xl px-4 py-16">
      <h1 className="text-center text-3xl font-extrabold text-slate-900">{t.title}</h1>
      <div className="mt-10 divide-y divide-slate-200 rounded-2xl border border-slate-200">
        {qas.map(([q, a]) => (
          <details key={q} className="group p-5 open:bg-slate-50">
            <summary className="cursor-pointer list-none font-semibold text-slate-900 marker:content-none">
              <span className="flex items-center justify-between gap-4">
                {q}
                <span className="text-brand-600 transition group-open:rotate-45">+</span>
              </span>
            </summary>
            <p className="mt-3 text-sm text-slate-600">{a}</p>
          </details>
        ))}
      </div>
    </div>
  );
}
