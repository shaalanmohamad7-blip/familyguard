import { isLocale, defaultLocale, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/getDictionary";

export default function FeaturesPage({ params }: { params: { locale: string } }) {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  const dict = getDictionary(locale);
  const t = dict.features;

  const items = [
    { ...t.location, icon: "🗺️" },
    { ...t.geofence, icon: "⭕" },
    { ...t.sos, icon: "🆘" },
    { ...t.screenTime, icon: "📊" },
    { ...t.limits, icon: "⏰" },
    { ...t.alerts, icon: "🔔" },
    { ...t.privacy, icon: "🔒" },
    { ...t.multiGuardian, icon: "👪" },
  ];

  return (
    <div className="mx-auto max-w-6xl px-4 py-16">
      <div className="mx-auto max-w-2xl text-center">
        <h1 className="text-3xl font-extrabold text-slate-900">{t.title}</h1>
        <p className="mt-3 text-slate-600">{t.subtitle}</p>
      </div>
      <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((f) => (
          <div key={f.title} className="rounded-2xl border border-slate-200 p-6 shadow-sm">
            <span className="text-3xl">{f.icon}</span>
            <h3 className="mt-3 font-semibold text-slate-900">{f.title}</h3>
            <p className="mt-2 text-sm text-slate-600">{f.body}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
