import { isLocale, defaultLocale, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/getDictionary";

export default function HowItWorksPage({ params }: { params: { locale: string } }) {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  const dict = getDictionary(locale);
  const t = dict.howItWorks;

  const steps = [
    [t.step1Title, t.step1Body],
    [t.step2Title, t.step2Body],
    [t.step3Title, t.step3Body],
    [t.step4Title, t.step4Body],
    [t.step5Title, t.step5Body],
    [t.step6Title, t.step6Body],
  ];

  return (
    <div className="mx-auto max-w-4xl px-4 py-16">
      <div className="mx-auto max-w-2xl text-center">
        <h1 className="text-3xl font-extrabold text-slate-900">{t.title}</h1>
        <p className="mt-3 text-slate-600">{t.subtitle}</p>
      </div>

      <ol className="mt-12 space-y-6 border-s-2 border-brand-200 ps-6">
        {steps.map(([title, body]) => (
          <li key={title} className="relative">
            <span className="absolute -start-[1.9rem] top-1 h-3 w-3 rounded-full bg-brand-600" />
            <h3 className="font-semibold text-slate-900">{title}</h3>
            <p className="mt-1 text-sm text-slate-600">{body}</p>
          </li>
        ))}
      </ol>

      <div className="mt-12 rounded-2xl border border-amber-200 bg-amber-50 p-6">
        <h3 className="font-semibold text-amber-900">{t.ongoingTitle}</h3>
        <p className="mt-2 text-sm text-amber-800">{t.ongoingBody}</p>
      </div>
    </div>
  );
}
