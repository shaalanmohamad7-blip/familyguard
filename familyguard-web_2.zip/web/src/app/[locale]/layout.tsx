import type { Metadata } from "next";
import "@/app/globals.css";
import { locales, localeDirection, isLocale, defaultLocale, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/getDictionary";
import Providers from "@/components/Providers";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export const metadata: Metadata = {
  title: "FamilyGuard — transparent family safety",
  description:
    "FamilyGuard is a consent-based family safety platform: location sharing, geofences, SOS, and Android screen-time tools, installed openly with no hidden surveillance.",
};

export default function LocaleLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: { locale: string };
}) {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  const dict = getDictionary(locale);
  const dir = localeDirection[locale];

  return (
    <html lang={locale} dir={dir}>
      <body className="flex min-h-screen flex-col bg-white text-slate-900 antialiased">
        <Providers>
          <Navbar locale={locale} dict={dict} />
          <main className="flex-1">{children}</main>
          <Footer locale={locale} dict={dict} />
        </Providers>
      </body>
    </html>
  );
}
