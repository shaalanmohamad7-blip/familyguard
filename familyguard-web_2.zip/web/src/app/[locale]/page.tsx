import Link from "next/link";
import { isLocale, defaultLocale, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/getDictionary";

export default function HomePage({ params }: { params: { locale: string } }) {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  const dict = getDictionary(locale);
  const t = dict.home;

  const badges = [t.trustBadge1, t.trustBadge2, t.trustBadge3, t.trustBadge4];
  const features = [
    { title: t.feature1Title, body: t.feature1Body, icon: "📍" },
    { title: t.feature2Title, body: t.feature2Body, icon: "⏱️" },
    { title: t.feature3Title, body: t.feature3Body, icon: "🆘" },
  ];

  return (
    <div>
      <section className="bg-gradient-to-b from-brand-50 to-white">
        <div className="mx-auto max-w-6xl px-4 py-20 text-center">
          <p className="mb-3 text-sm font-semibold uppercase tracking-wide text-brand-700">
            {t.heroEyebrow}
          </p>
          <h1 className="mx-auto max-w-3xl text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">
            {t.heroTitle}
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-lg text-slate-600">{t.heroSubtitle}</p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link
              href={`/${locale}/signup`}
              className="rounded-full bg-brand-600 px-6 py-3 text-sm font-semibold text-white shadow hover:bg-brand-700"
            >
              {t.ctaPrimary}
            </Link>
            <Link
              href={`/${locale}/how-it-works`}
              className="rounded-full border border-slate-300 px-6 py-3 text-sm font-semibold text-slate-700 hover:border-brand-400 hover:text-brand-700"
            >
              {t.ctaSecondary}
            </Link>
          </div>
          <div className="mx-auto mt-10 grid max-w-3xl grid-cols-2 gap-3 sm:grid-cols-4">
            {badges.map((b) => (
              <div
                key={b}
                className="rounded-xl border border-slate-200 bg-white px-3 py-3 text-xs font-medium text-slate-600 shadow-sm"
              >
                {b}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16">
        <div className="grid gap-10 lg:grid-cols-2 lg:items-center">
          <div>
            <h2 className="text-2xl font-bold text-slate-900">{t.sectionWhyTitle}</h2>
            <p className="mt-3 text-slate-600">{t.sectionWhyBody}</p>
          </div>
          <div className="grid gap-4">
            {features.map((f) => (
              <div key={f.title} className="flex gap-4 rounded-2xl border border-slate-200 p-5">
                <span className="text-2xl">{f.icon}</span>
                <div>
                  <h3 className="font-semibold text-slate-900">{f.title}</h3>
                  <p className="mt-1 text-sm text-slate-600">{f.body}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-slate-900 py-16 text-white">
        <div className="mx-auto max-w-4xl px-4 text-center">
          <h2 className="text-2xl font-bold">{t.sectionHonestyTitle}</h2>
          <p className="mt-3 text-slate-300">{t.sectionHonestyBody}</p>
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-4 py-16 text-center">
        <h2 className="text-2xl font-bold text-slate-900">{t.finalCtaTitle}</h2>
        <p className="mt-3 text-slate-600">{t.finalCtaBody}</p>
        <Link
          href={`/${locale}/signup`}
          className="mt-6 inline-block rounded-full bg-brand-600 px-6 py-3 text-sm font-semibold text-white shadow hover:bg-brand-700"
        >
          {t.finalCtaButton}
        </Link>
      </section>
    </div>
  );
}
