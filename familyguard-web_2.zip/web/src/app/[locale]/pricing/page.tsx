import { redirect } from "next/navigation";
import { isLocale, defaultLocale, type Locale } from "@/i18n/config";

// Pricing was removed — FamilyGuard is free. Send any old link to sign-up.
export default function PricingPage({ params }: { params: { locale: string } }) {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  redirect(`/${locale}/signup`);
}
