import { Suspense } from "react";
import { isLocale, defaultLocale, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/getDictionary";
import SignInForm from "@/components/SignInForm";

export default function SignInPage({ params }: { params: { locale: string } }) {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  const dict = getDictionary(locale);

  return (
    <Suspense>
      <SignInForm locale={locale} dict={dict} />
    </Suspense>
  );
}
