import { isLocale, defaultLocale, type Locale } from "@/i18n/config";
import { getDictionary } from "@/i18n/getDictionary";
import SupportForm from "@/components/SupportForm";

export default function SupportPage({ params }: { params: { locale: string } }) {
  const locale: Locale = isLocale(params.locale) ? params.locale : defaultLocale;
  const dict = getDictionary(locale);
  const t = dict.support;

  const helpItems = [t.help1, t.help2, t.help3, t.help4];

  return (
    <div className="mx-auto max-w-4xl px-4 py-16">
      <div className="mx-auto max-w-2xl text-center">
        <h1 className="text-3xl font-extrabold text-slate-900">{t.title}</h1>
        <p className="mt-3 text-slate-600">{t.subtitle}</p>
      </div>

      <div className="mt-12 grid gap-8 lg:grid-cols-2">
        <div className="rounded-2xl border border-slate-200 p-6">
          <h2 className="font-semibold text-slate-900">{t.emailTitle}</h2>
          <p className="mt-1 text-sm text-slate-600">{t.emailBody}</p>
          <div className="mt-5">
            <SupportForm t={t} />
          </div>
        </div>
        <div className="rounded-2xl border border-slate-200 p-6">
          <h2 className="font-semibold text-slate-900">{t.helpTitle}</h2>
          <ul className="mt-3 space-y-2 text-sm text-slate-600">
            {helpItems.map((item) => (
              <li key={item} className="rounded-lg bg-slate-50 px-3 py-2">
                {item}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
