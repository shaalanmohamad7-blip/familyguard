import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { authenticateDevice } from "@/lib/deviceAuth";

export const dynamic = "force-dynamic";

// What the companion app's "connected guardians" screen reads. Deliberately
// returns names only — never emails or any other guardian PII.
export async function GET(req: Request, { params }: { params: { id: string } }) {
  const claims = authenticateDevice(req);
  if (!claims || claims.deviceId !== params.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const family = await prisma.family.findUnique({
    where: { id: claims.familyId },
    include: {
      members: {
        include: { user: { select: { name: true } } },
      },
    },
  });

  if (!family) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  return NextResponse.json({
    familyName: family.name,
    guardians: family.members.map((m) => ({ name: m.user.name })),
  });
}
