import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { authenticateDevice } from "@/lib/deviceAuth";
import { logAccess } from "@/lib/accessLog";

export const dynamic = "force-dynamic";

const schema = z.object({
  token: z.string().min(1).max(4096),
});

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const claims = authenticateDevice(req);
  if (!claims || claims.deviceId !== params.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const json = await req.json().catch(() => null);
  const parsed = schema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid input" }, { status: 400 });
  }

  const device = await prisma.device.findFirst({
    where: { id: claims.deviceId, familyId: claims.familyId },
  });
  if (!device || device.status === "REVOKED") {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  await prisma.device.update({
    where: { id: device.id },
    data: { fcmToken: parsed.data.token },
  });

  await logAccess({
    familyId: claims.familyId,
    actorType: "DEVICE",
    actorId: claims.deviceId,
    action: "FCM_TOKEN_REGISTERED",
    targetType: "Device",
    targetId: device.id,
  });

  return NextResponse.json({ ok: true });
}
