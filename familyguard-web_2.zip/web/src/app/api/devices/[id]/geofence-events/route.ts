import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { authenticateDevice } from "@/lib/deviceAuth";
import { logAccess } from "@/lib/accessLog";

export const dynamic = "force-dynamic";

const schema = z.object({
  geofenceId: z.string().min(1),
  transition: z.enum(["ARRIVAL", "DEPARTURE"]),
  occurredAt: z.string(),
  lat: z.number().min(-90).max(90),
  lng: z.number().min(-180).max(180),
});

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const claims = authenticateDevice(req);
  if (!claims || claims.deviceId !== params.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const json = await req.json().catch(() => null);
  const parsed = schema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid input" }, { status: 400 });
  }

  const device = await prisma.device.findFirst({
    where: { id: claims.deviceId, familyId: claims.familyId },
  });
  if (!device || device.status === "REVOKED") {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const geofence = await prisma.geofence.findFirst({
    where: { id: parsed.data.geofenceId, familyId: claims.familyId },
  });
  if (!geofence) {
    return NextResponse.json({ error: "Geofence not found" }, { status: 404 });
  }

  const alertType = parsed.data.transition === "ARRIVAL" ? "GEOFENCE_ARRIVAL" : "GEOFENCE_DEPARTURE";
  const shouldAlert =
    parsed.data.transition === "ARRIVAL" ? geofence.alertOnArrival : geofence.alertOnDeparture;

  if (!shouldAlert) {
    return NextResponse.json({ ok: true, alertCreated: false });
  }

  const alert = await prisma.alert.create({
    data: {
      familyId: claims.familyId,
      deviceId: device.id,
      type: alertType,
      payload: {
        geofenceId: geofence.id,
        geofenceName: geofence.name,
        lat: parsed.data.lat,
        lng: parsed.data.lng,
        occurredAt: parsed.data.occurredAt,
      },
    },
  });

  await logAccess({
    familyId: claims.familyId,
    actorType: "DEVICE",
    actorId: claims.deviceId,
    action: "GEOFENCE_EVENT",
    targetType: "Alert",
    targetId: alert.id,
  });

  return NextResponse.json({ ok: true, alertCreated: true, alertId: alert.id });
}
