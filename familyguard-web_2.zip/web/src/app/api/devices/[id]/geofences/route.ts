import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { authenticateDevice } from "@/lib/deviceAuth";

export const dynamic = "force-dynamic";

// Device-facing: lets the companion app fetch the geofences it should
// evaluate locally, without exposing anything about other families.
export async function GET(req: Request, { params }: { params: { id: string } }) {
  const claims = authenticateDevice(req);
  if (!claims || claims.deviceId !== params.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const device = await prisma.device.findFirst({
    where: { id: claims.deviceId, familyId: claims.familyId },
  });
  if (!device || device.status === "REVOKED") {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const geofences = await prisma.geofence.findMany({
    where: { familyId: claims.familyId },
    select: {
      id: true,
      name: true,
      lat: true,
      lng: true,
      radiusM: true,
      alertOnArrival: true,
      alertOnDeparture: true,
    },
  });

  return NextResponse.json({ geofences });
}
