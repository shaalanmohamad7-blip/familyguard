import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { authenticateDevice } from "@/lib/deviceAuth";
import { requireParentContext, getFamilyDevice } from "@/lib/parentSession";
import { logAccess } from "@/lib/accessLog";

export const dynamic = "force-dynamic";

// Device-facing: the companion app reads the current limit rule to enforce
// locally (Android only — this endpoint is simply never called from iOS).
export async function GET(req: Request, { params }: { params: { id: string } }) {
  const claims = authenticateDevice(req);
  if (!claims || claims.deviceId !== params.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const device = await prisma.device.findFirst({
    where: { id: claims.deviceId, familyId: claims.familyId },
  });
  if (!device || device.status === "REVOKED") {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const limit = await prisma.limitRule.findUnique({ where: { deviceId: device.id } });
  return NextResponse.json({ limit });
}

const limitSchema = z.object({
  dailyLimitMinutes: z.number().int().min(0).max(1440).nullable().optional(),
  windowStart: z.string().max(5).nullable().optional(),
  windowEnd: z.string().max(5).nullable().optional(),
  daysOfWeek: z.array(z.number().int().min(0).max(6)).optional(),
  bedtimeStart: z.string().max(5).nullable().optional(),
  bedtimeEnd: z.string().max(5).nullable().optional(),
});

// Parent-facing: create/update the limit rule for a device they own.
export async function POST(req: Request, { params }: { params: { id: string } }) {
  const ctx = await requireParentContext();
  if (!ctx) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const device = await getFamilyDevice(ctx.familyId, params.id);
  if (!device) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const json = await req.json().catch(() => null);
  const parsed = limitSchema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid input" }, { status: 400 });
  }

  const data = {
    dailyLimitMinutes: parsed.data.dailyLimitMinutes ?? null,
    windowStart: parsed.data.windowStart ?? null,
    windowEnd: parsed.data.windowEnd ?? null,
    daysOfWeek: parsed.data.daysOfWeek ?? [],
    bedtimeStart: parsed.data.bedtimeStart ?? null,
    bedtimeEnd: parsed.data.bedtimeEnd ?? null,
  };

  const limit = await prisma.limitRule.upsert({
    where: { deviceId: device.id },
    create: { deviceId: device.id, ...data },
    update: data,
  });

  await logAccess({
    familyId: ctx.familyId,
    actorType: "USER",
    actorId: ctx.userId,
    action: "LIMIT_RULE_UPDATED",
    targetType: "LimitRule",
    targetId: limit.id,
  });

  return NextResponse.json({ limit });
}
