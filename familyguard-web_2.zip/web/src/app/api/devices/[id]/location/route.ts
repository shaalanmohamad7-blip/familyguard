import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { authenticateDevice } from "@/lib/deviceAuth";
import { logAccess } from "@/lib/accessLog";

export const dynamic = "force-dynamic";

const schema = z.object({
  lat: z.number().min(-90).max(90),
  lng: z.number().min(-180).max(180),
  accuracyM: z.number().min(0).max(100000),
  capturedAt: z.string().min(1),
  source: z.enum(["BACKGROUND", "CHECK_IN", "SOS"]),
});

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const claims = authenticateDevice(req);
  if (!claims || claims.deviceId !== params.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const json = await req.json().catch(() => null);
  const parsed = schema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid input" }, { status: 400 });
  }

  const device = await prisma.device.findFirst({
    where: { id: claims.deviceId, familyId: claims.familyId },
  });
  if (!device || device.status === "REVOKED") {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const point = await prisma.locationPoint.create({
    data: {
      deviceId: device.id,
      lat: parsed.data.lat,
      lng: parsed.data.lng,
      accuracyM: parsed.data.accuracyM,
      capturedAt: new Date(parsed.data.capturedAt),
      source: parsed.data.source,
    },
  });

  await prisma.device.update({
    where: { id: device.id },
    data: { lastSeenAt: new Date(), status: "ACTIVE" },
  });

  await logAccess({
    familyId: claims.familyId,
    actorType: "DEVICE",
    actorId: claims.deviceId,
    action: "LOCATION_REPORTED",
    targetType: "LocationPoint",
    targetId: point.id,
  });

  return NextResponse.json({ ok: true, id: point.id });
}
