import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireParentContext, getFamilyDevice } from "@/lib/parentSession";

export const dynamic = "force-dynamic";

export async function GET(req: Request, { params }: { params: { id: string } }) {
  const ctx = await requireParentContext();
  if (!ctx) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const device = await getFamilyDevice(ctx.familyId, params.id);
  if (!device) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const { searchParams } = new URL(req.url);
  const since = searchParams.get("since");

  const locations = await prisma.locationPoint.findMany({
    where: {
      deviceId: device.id,
      ...(since ? { capturedAt: { gte: new Date(since) } } : {}),
    },
    orderBy: { capturedAt: "desc" },
    take: 500,
  });

  return NextResponse.json({ locations });
}
