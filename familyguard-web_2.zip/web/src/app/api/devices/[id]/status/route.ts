import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { authenticateDevice } from "@/lib/deviceAuth";
import { logAccess } from "@/lib/accessLog";

export const dynamic = "force-dynamic";

const schema = z.object({
  batteryPct: z.number().int().min(0).max(100).optional(),
  permissions: z
    .object({
      locationFg: z.boolean().optional(),
      locationBg: z.boolean().optional(),
      usageAccess: z.boolean().optional(),
      notifications: z.boolean().optional(),
    })
    .optional(),
  appVersion: z.string().max(50).optional(),
});

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const claims = authenticateDevice(req);
  if (!claims || claims.deviceId !== params.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const json = await req.json().catch(() => null);
  const parsed = schema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid input" }, { status: 400 });
  }

  const device = await prisma.device.findFirst({
    where: { id: claims.deviceId, familyId: claims.familyId },
  });
  if (!device || device.status === "REVOKED") {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const existingPermissions: Record<string, boolean> =
    device.permissions && typeof device.permissions === "object" && !Array.isArray(device.permissions)
      ? (device.permissions as unknown as Record<string, boolean>)
      : {};

  const mergedPermissions: Record<string, boolean> = parsed.data.permissions
    ? {
        ...existingPermissions,
        ...(Object.fromEntries(
          Object.entries(parsed.data.permissions).filter(([, v]) => v !== undefined)
        ) as Record<string, boolean>),
      }
    : existingPermissions;

  const updated = await prisma.device.update({
    where: { id: device.id },
    data: {
      lastSeenAt: new Date(),
      status: "ACTIVE",
      ...(parsed.data.batteryPct !== undefined ? { batteryPct: parsed.data.batteryPct } : {}),
      ...(parsed.data.appVersion !== undefined ? { appVersion: parsed.data.appVersion } : {}),
      ...(parsed.data.permissions ? { permissions: mergedPermissions } : {}),
    },
  });

  await logAccess({
    familyId: claims.familyId,
    actorType: "DEVICE",
    actorId: claims.deviceId,
    action: "STATUS_REPORTED",
    targetType: "Device",
    targetId: device.id,
  });

  return NextResponse.json({ ok: true, device: { id: updated.id, status: updated.status } });
}
