import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireParentContext, getFamilyDevice } from "@/lib/parentSession";
import { logAccess } from "@/lib/accessLog";

export const dynamic = "force-dynamic";

// Revokes the device's ability to authenticate; its token will be rejected
// by every device-facing route once status is REVOKED and lookups filter on it.
export async function POST(_req: Request, { params }: { params: { id: string } }) {
  const ctx = await requireParentContext();
  if (!ctx) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const device = await getFamilyDevice(ctx.familyId, params.id);
  if (!device) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const updated = await prisma.device.update({
    where: { id: device.id },
    data: { status: "REVOKED", fcmToken: null },
  });

  await logAccess({
    familyId: ctx.familyId,
    actorType: "USER",
    actorId: ctx.userId,
    action: "DEVICE_UNLINKED",
    targetType: "Device",
    targetId: device.id,
  });

  return NextResponse.json({ ok: true, device: { id: updated.id, status: updated.status } });
}
