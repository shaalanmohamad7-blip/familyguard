import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireParentContext } from "@/lib/parentSession";

export const dynamic = "force-dynamic";

export async function GET() {
  const ctx = await requireParentContext();
  if (!ctx) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const family = await prisma.family.findUnique({
    where: { id: ctx.familyId },
    include: {
      devices: {
        orderBy: { pairedAt: "asc" },
        include: { limitRule: true },
      },
      members: { include: { user: { select: { id: true, name: true, email: true } } } },
    },
  });

  if (!family) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  return NextResponse.json({ family, role: ctx.role });
}
