import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireParentContext } from "@/lib/parentSession";
import { logAccess } from "@/lib/accessLog";

export const dynamic = "force-dynamic";

const patchSchema = z.object({
  name: z.string().min(1).max(120).optional(),
  lat: z.number().min(-90).max(90).optional(),
  lng: z.number().min(-180).max(180).optional(),
  radiusM: z.number().int().min(10).max(50000).optional(),
  alertOnArrival: z.boolean().optional(),
  alertOnDeparture: z.boolean().optional(),
});

async function getOwnedGeofence(familyId: string, id: string) {
  return prisma.geofence.findFirst({ where: { id, familyId } });
}

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const ctx = await requireParentContext();
  if (!ctx) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const existing = await getOwnedGeofence(ctx.familyId, params.id);
  if (!existing) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const json = await req.json().catch(() => null);
  const parsed = patchSchema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid input" }, { status: 400 });
  }

  const geofence = await prisma.geofence.update({
    where: { id: existing.id },
    data: parsed.data,
  });

  await logAccess({
    familyId: ctx.familyId,
    actorType: "USER",
    actorId: ctx.userId,
    action: "GEOFENCE_UPDATED",
    targetType: "Geofence",
    targetId: geofence.id,
  });

  return NextResponse.json({ geofence });
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  const ctx = await requireParentContext();
  if (!ctx) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const existing = await getOwnedGeofence(ctx.familyId, params.id);
  if (!existing) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  await prisma.geofence.delete({ where: { id: existing.id } });

  await logAccess({
    familyId: ctx.familyId,
    actorType: "USER",
    actorId: ctx.userId,
    action: "GEOFENCE_DELETED",
    targetType: "Geofence",
    targetId: existing.id,
  });

  return NextResponse.json({ ok: true });
}
