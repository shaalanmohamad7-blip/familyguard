import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireParentContext } from "@/lib/parentSession";
import { logAccess } from "@/lib/accessLog";

export const dynamic = "force-dynamic";

const schema = z.object({
  name: z.string().min(1).max(120),
  lat: z.number().min(-90).max(90),
  lng: z.number().min(-180).max(180),
  radiusM: z.number().int().min(10).max(50000),
  alertOnArrival: z.boolean().optional(),
  alertOnDeparture: z.boolean().optional(),
});

export async function POST(req: Request) {
  const ctx = await requireParentContext();
  if (!ctx) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const json = await req.json().catch(() => null);
  const parsed = schema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid input" }, { status: 400 });
  }

  const geofence = await prisma.geofence.create({
    data: {
      familyId: ctx.familyId,
      name: parsed.data.name,
      lat: parsed.data.lat,
      lng: parsed.data.lng,
      radiusM: parsed.data.radiusM,
      alertOnArrival: parsed.data.alertOnArrival ?? true,
      alertOnDeparture: parsed.data.alertOnDeparture ?? true,
    },
  });

  await logAccess({
    familyId: ctx.familyId,
    actorType: "USER",
    actorId: ctx.userId,
    action: "GEOFENCE_CREATED",
    targetType: "Geofence",
    targetId: geofence.id,
  });

  return NextResponse.json({ geofence }, { status: 201 });
}
