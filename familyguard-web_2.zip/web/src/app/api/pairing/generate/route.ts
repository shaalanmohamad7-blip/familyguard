import { NextResponse } from "next/server";
import crypto from "crypto";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireParentContext } from "@/lib/parentSession";
import { logAccess } from "@/lib/accessLog";

export const dynamic = "force-dynamic";

const schema = z.object({
  deviceLabel: z.string().min(1).max(120),
});

function generateCode(): string {
  // 8-character, human-typeable code (uppercase letters + digits, excludes ambiguous chars).
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  const bytes = crypto.randomBytes(8);
  for (let i = 0; i < 8; i++) {
    code += alphabet[bytes[i] % alphabet.length];
  }
  return code;
}

export async function POST(req: Request) {
  const ctx = await requireParentContext();
  if (!ctx) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const json = await req.json().catch(() => null);
  const parsed = schema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid input" }, { status: 400 });
  }

  const expiresAt = new Date(Date.now() + 15 * 60 * 1000);
  let code = generateCode();

  // Extremely unlikely collision, but guard against it since code is unique.
  for (let attempt = 0; attempt < 5; attempt++) {
    const clash = await prisma.pairingCode.findUnique({ where: { code } });
    if (!clash) break;
    code = generateCode();
  }

  const pairing = await prisma.pairingCode.create({
    data: {
      code,
      familyId: ctx.familyId,
      deviceLabel: parsed.data.deviceLabel,
      expiresAt,
    },
  });

  await logAccess({
    familyId: ctx.familyId,
    actorType: "USER",
    actorId: ctx.userId,
    action: "PAIRING_CODE_GENERATED",
    targetType: "PairingCode",
    targetId: pairing.id,
  });

  return NextResponse.json({ code: pairing.code, expiresAt: pairing.expiresAt });
}
