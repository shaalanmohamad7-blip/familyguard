import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { signDeviceToken } from "@/lib/deviceAuth";
import { logAccess } from "@/lib/accessLog";

export const dynamic = "force-dynamic";

const schema = z.object({
  code: z.string().min(4).max(32),
  platform: z.enum(["ANDROID", "IOS"]).default("ANDROID"),
  appVersion: z.string().max(50).optional(),
});

// No authentication is possible here by design: this is the very first
// contact a not-yet-paired device makes. The single-use, time-limited code
// (generated only from an authenticated parent session) is the credential.
export async function POST(req: Request) {
  const json = await req.json().catch(() => null);
  const parsed = schema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid input" }, { status: 400 });
  }

  const { code, platform, appVersion } = parsed.data;
  const normalizedCode = code.trim().toUpperCase();

  const pairing = await prisma.pairingCode.findUnique({ where: { code: normalizedCode } });
  if (!pairing) {
    return NextResponse.json({ error: "Invalid or expired code" }, { status: 404 });
  }
  if (pairing.redeemedAt) {
    return NextResponse.json({ error: "Code already used" }, { status: 410 });
  }
  if (pairing.expiresAt.getTime() < Date.now()) {
    return NextResponse.json({ error: "Code expired" }, { status: 410 });
  }

  const result = await prisma.$transaction(async (tx) => {
    const device = await tx.device.create({
      data: {
        familyId: pairing.familyId,
        label: pairing.deviceLabel,
        platform,
        status: "ACTIVE",
        appVersion,
        permissions: {},
      },
    });
    await tx.pairingCode.update({
      where: { id: pairing.id },
      data: { redeemedAt: new Date(), redeemedDeviceId: device.id },
    });
    return device;
  });

  await logAccess({
    familyId: pairing.familyId,
    actorType: "DEVICE",
    actorId: result.id,
    action: "PAIRING_CODE_REDEEMED",
    targetType: "Device",
    targetId: result.id,
  });

  const deviceToken = signDeviceToken({ deviceId: result.id, familyId: pairing.familyId });

  return NextResponse.json({
    deviceToken,
    deviceId: result.id,
    familyId: pairing.familyId,
  });
}
