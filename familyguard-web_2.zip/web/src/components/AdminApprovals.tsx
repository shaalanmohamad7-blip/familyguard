"use client";

import { useState } from "react";

interface PendingUser {
  id: string;
  name: string;
  email: string;
  familyName: string | null;
  createdAt: string;
}

export default function AdminApprovals({
  initialUsers,
  ar,
}: {
  initialUsers: PendingUser[];
  ar: boolean;
}) {
  const [users, setUsers] = useState<PendingUser[]>(initialUsers);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function decide(userId: string, decision: "approve" | "reject") {
    setBusy(userId);
    setError(null);
    try {
      const res = await fetch("/api/admin/decide", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, decision }),
      });
      if (!res.ok) throw new Error("request failed");
      setUsers((prev) => prev.filter((u) => u.id !== userId));
    } catch {
      setError(ar ? "صار خطأ، حاول مرة ثانية." : "Something went wrong, please try again.");
    } finally {
      setBusy(null);
    }
  }

  if (users.length === 0) {
    return (
      <p className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-8 text-center text-sm text-slate-500">
        {ar ? "لا توجد حسابات قيد الانتظار حاليًا." : "No accounts are waiting for approval right now."}
      </p>
    );
  }

  return (
    <div className="space-y-3">
      {error && <p className="text-sm text-red-600">{error}</p>}
      {users.map((u) => (
        <div
          key={u.id}
          className="flex flex-col gap-3 rounded-xl border border-slate-200 p-4 sm:flex-row sm:items-center sm:justify-between"
        >
          <div>
            <div className="font-semibold text-slate-900">{u.name}</div>
            <div className="text-sm text-slate-500">{u.email}</div>
            {u.familyName && (
              <div className="mt-0.5 text-xs text-slate-400">
                {(ar ? "العائلة: " : "Family: ") + u.familyName}
              </div>
            )}
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => decide(u.id, "approve")}
              disabled={busy === u.id}
              className="rounded-full bg-emerald-600 px-4 py-1.5 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-60"
            >
              {ar ? "موافقة" : "Approve"}
            </button>
            <button
              onClick={() => decide(u.id, "reject")}
              disabled={busy === u.id}
              className="rounded-full border border-red-300 px-4 py-1.5 text-sm font-semibold text-red-600 hover:bg-red-50 disabled:opacity-60"
            >
              {ar ? "رفض" : "Reject"}
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
