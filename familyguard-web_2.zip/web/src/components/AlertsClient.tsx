"use client";

import { useState } from "react";
import type { Dictionary } from "@/i18n/getDictionary";
import type { Locale } from "@/i18n/config";

interface AlertRow {
  id: string;
  type: string;
  createdAt: string;
  acknowledgedAt: string | null;
  device: { id: string; label: string } | null;
  payload: Record<string, unknown>;
}

export default function AlertsClient({
  initial,
  t,
  locale,
}: {
  initial: AlertRow[];
  t: Dictionary["dashboard"]["alerts"];
  locale: Locale;
}) {
  const [alerts, setAlerts] = useState(initial);

  async function ack(id: string) {
    const res = await fetch(`/api/alerts/${id}/ack`, { method: "POST" });
    if (res.ok) {
      const data = await res.json();
      setAlerts((prev) => prev.map((a) => (a.id === id ? { ...a, acknowledgedAt: data.alert.acknowledgedAt } : a)));
    }
  }

  const typeLabels = t.type as unknown as Record<string, string>;

  if (alerts.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed border-slate-300 p-10 text-center text-slate-500">
        {t.noAlerts}
      </div>
    );
  }

  return (
    <div className="grid gap-3">
      {alerts.map((a) => {
        const isSOS = a.type === "SOS";
        const isUrgent = isSOS && !a.acknowledgedAt;
        return (
          <div
            key={a.id}
            className={`flex flex-wrap items-center justify-between gap-3 rounded-2xl border p-4 ${
              isUrgent
                ? "border-red-300 bg-red-50"
                : a.acknowledgedAt
                ? "border-slate-200 opacity-70"
                : "border-slate-200"
            }`}
          >
            <div>
              <div className="flex items-center gap-2">
                {isUrgent && <span className="animate-pulse text-red-600">&#9679;</span>}
                <h3 className={`font-semibold ${isUrgent ? "text-red-800" : "text-slate-900"}`}>
                  {typeLabels[a.type] ?? a.type}
                </h3>
              </div>
              <p className="text-xs text-slate-500">
                {a.device?.label ?? "—"} &middot;{" "}
                {new Date(a.createdAt).toLocaleString(locale === "ar" ? "ar" : "en-US")}
              </p>
            </div>
            {a.acknowledgedAt ? (
              <span className="text-xs font-semibold text-slate-500">{t.acknowledged}</span>
            ) : (
              <button
                onClick={() => ack(a.id)}
                className={`rounded-full px-4 py-1.5 text-sm font-semibold ${
                  isUrgent
                    ? "bg-red-600 text-white hover:bg-red-700"
                    : "border border-slate-300 text-slate-700 hover:border-brand-400"
                }`}
              >
                {t.acknowledge}
              </button>
            )}
          </div>
        );
      })}
    </div>
  );
}
