"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import type { Locale } from "@/i18n/config";
import type { Dictionary } from "@/i18n/getDictionary";

export default function DashboardNav({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  const pathname = usePathname() || "";
  const t = dict.dashboard.nav;

  const items: [string, string][] = [
    [t.overview, `/${locale}/dashboard`],
    [t.map, `/${locale}/dashboard/map`],
    [t.geofences, `/${locale}/dashboard/geofences`],
    [t.alerts, `/${locale}/dashboard/alerts`],
    [t.settings, `/${locale}/dashboard/settings`],
  ];

  return (
    <>
      <nav className="sticky top-20 hidden h-fit w-52 shrink-0 rounded-2xl border border-slate-200 p-3 sm:block">
        <ul className="space-y-1 text-sm font-medium">
          {items.map(([label, href]) => {
            const active = pathname === href;
            return (
              <li key={href}>
                <Link
                  href={href}
                  className={`block rounded-lg px-3 py-2 transition ${
                    active ? "bg-brand-600 text-white" : "text-slate-600 hover:bg-slate-100"
                  }`}
                >
                  {label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      <nav className="-mx-4 mb-4 flex gap-2 overflow-x-auto px-4 pb-1 sm:hidden">
        {items.map(([label, href]) => {
          const active = pathname === href;
          return (
            <Link
              key={href}
              href={href}
              className={`shrink-0 rounded-full px-3 py-1.5 text-xs font-semibold ${
                active ? "bg-brand-600 text-white" : "border border-slate-200 text-slate-600"
              }`}
            >
              {label}
            </Link>
          );
        })}
      </nav>
    </>
  );
}
