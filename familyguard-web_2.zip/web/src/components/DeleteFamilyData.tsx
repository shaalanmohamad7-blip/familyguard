"use client";

import { useState } from "react";
import { signOut } from "next-auth/react";
import type { Dictionary } from "@/i18n/getDictionary";
import type { Locale } from "@/i18n/config";

export default function DeleteFamilyData({
  locale,
  t,
}: {
  locale: Locale;
  t: Dictionary["dashboard"]["settings"];
}) {
  const [open, setOpen] = useState(false);
  const [confirmText, setConfirmText] = useState("");
  const [deleting, setDeleting] = useState(false);

  async function confirmDelete() {
    setDeleting(true);
    await fetch("/api/account/delete", { method: "POST" });
    await signOut({ callbackUrl: `/${locale}` });
  }

  return (
    <div className="rounded-2xl border border-red-200 bg-red-50 p-5">
      <h3 className="font-semibold text-red-900">{t.dangerTitle}</h3>
      <p className="mt-1 text-sm text-red-800">{t.dangerBody}</p>
      <button
        onClick={() => setOpen(true)}
        className="mt-4 rounded-full bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-700"
      >
        {t.dangerButton}
      </button>

      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-xl">
            <h3 className="text-lg font-bold text-slate-900">{t.confirmTitle}</h3>
            <p className="mt-2 text-sm text-slate-600">{t.confirmBody}</p>
            <input
              value={confirmText}
              onChange={(e) => setConfirmText(e.target.value)}
              placeholder={t.confirmPlaceholder}
              className="mt-4 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
            <div className="mt-5 flex justify-end gap-2">
              <button
                onClick={() => {
                  setOpen(false);
                  setConfirmText("");
                }}
                className="rounded-full border border-slate-300 px-4 py-2 text-sm font-medium text-slate-600"
              >
                {t.cancelButton}
              </button>
              <button
                onClick={confirmDelete}
                disabled={confirmText !== "DELETE" || deleting}
                className="rounded-full bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-700 disabled:opacity-50"
              >
                {t.confirmButton}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
