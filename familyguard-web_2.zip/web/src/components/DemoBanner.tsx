export default function DemoBanner({ text }: { text: string }) {
  return (
    <div className="mb-6 flex items-center gap-2 rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 text-sm font-medium text-amber-900">
      <span className="text-lg">&#9888;&#65039;</span>
      <span>{text}</span>
    </div>
  );
}
