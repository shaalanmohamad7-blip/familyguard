"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import type { Dictionary } from "@/i18n/getDictionary";
import type { Locale } from "@/i18n/config";

interface LimitRule {
  dailyLimitMinutes: number | null;
  windowStart: string | null;
  windowEnd: string | null;
  bedtimeStart: string | null;
  bedtimeEnd: string | null;
}

export function UnlinkDeviceButton({
  deviceId,
  locale,
  t,
  redirectToOverview = true,
}: {
  deviceId: string;
  locale: Locale;
  t: Dictionary["dashboard"]["device"];
  redirectToOverview?: boolean;
}) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function unlink() {
    if (!confirm(t.confirmUnlink)) return;
    setLoading(true);
    await fetch(`/api/devices/${deviceId}/unlink`, { method: "POST" });
    setLoading(false);
    if (redirectToOverview) {
      router.push(`/${locale}/dashboard`);
    }
    router.refresh();
  }

  return (
    <button
      onClick={unlink}
      disabled={loading}
      className="rounded-full border border-red-300 px-4 py-2 text-sm font-semibold text-red-600 hover:bg-red-50 disabled:opacity-60"
    >
      {t.unlink}
    </button>
  );
}

export function LimitRuleForm({
  deviceId,
  initial,
  t,
}: {
  deviceId: string;
  initial: LimitRule | null;
  t: Dictionary["dashboard"]["usage"];
}) {
  const [dailyLimitMinutes, setDailyLimitMinutes] = useState(
    initial?.dailyLimitMinutes != null ? String(initial.dailyLimitMinutes) : ""
  );
  const [windowStart, setWindowStart] = useState(initial?.windowStart ?? "");
  const [windowEnd, setWindowEnd] = useState(initial?.windowEnd ?? "");
  const [bedtimeStart, setBedtimeStart] = useState(initial?.bedtimeStart ?? "");
  const [bedtimeEnd, setBedtimeEnd] = useState(initial?.bedtimeEnd ?? "");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setSaved(false);
    await fetch(`/api/devices/${deviceId}/limits`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        dailyLimitMinutes: dailyLimitMinutes ? parseInt(dailyLimitMinutes, 10) : null,
        windowStart: windowStart || null,
        windowEnd: windowEnd || null,
        bedtimeStart: bedtimeStart || null,
        bedtimeEnd: bedtimeEnd || null,
      }),
    });
    setSaving(false);
    setSaved(true);
  }

  return (
    <form onSubmit={save} className="grid gap-4 sm:grid-cols-2">
      <div>
        <label className="mb-1 block text-sm font-medium text-slate-700">{t.dailyLimit}</label>
        <input
          type="number"
          min={0}
          max={1440}
          value={dailyLimitMinutes}
          onChange={(e) => setDailyLimitMinutes(e.target.value)}
          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
        />
      </div>
      <div className="grid grid-cols-2 gap-2">
        <div>
          <label className="mb-1 block text-sm font-medium text-slate-700">{t.windowStart}</label>
          <input
            type="time"
            value={windowStart}
            onChange={(e) => setWindowStart(e.target.value)}
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium text-slate-700">{t.windowEnd}</label>
          <input
            type="time"
            value={windowEnd}
            onChange={(e) => setWindowEnd(e.target.value)}
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
          />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2 sm:col-span-2">
        <div>
          <label className="mb-1 block text-sm font-medium text-slate-700">{t.bedtimeStart}</label>
          <input
            type="time"
            value={bedtimeStart}
            onChange={(e) => setBedtimeStart(e.target.value)}
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium text-slate-700">{t.bedtimeEnd}</label>
          <input
            type="time"
            value={bedtimeEnd}
            onChange={(e) => setBedtimeEnd(e.target.value)}
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
          />
        </div>
      </div>
      <div className="flex items-center gap-3 sm:col-span-2">
        <button
          type="submit"
          disabled={saving}
          className="rounded-full bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700 disabled:opacity-60"
        >
          {t.saveLimits}
        </button>
        {saved && <span className="text-sm text-emerald-600">&#10003;</span>}
      </div>
    </form>
  );
}
