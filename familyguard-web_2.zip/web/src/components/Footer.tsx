import Link from "next/link";
import type { Locale } from "@/i18n/config";
import type { Dictionary } from "@/i18n/getDictionary";

export default function Footer({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  return (
    <footer className="border-t border-slate-200 bg-slate-50">
      <div className="mx-auto max-w-6xl px-4 py-10">
        <div className="grid gap-8 sm:grid-cols-3">
          <div>
            <div className="mb-2 flex items-center gap-2 font-bold text-slate-900">
              <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-brand-600 text-xs text-white">
                FG
              </span>
              {dict.meta.siteName}
            </div>
            <p className="max-w-xs text-sm text-slate-500">{dict.footer.tagline}</p>
          </div>
          <div>
            <h3 className="mb-2 text-sm font-semibold text-slate-900">{dict.footer.product}</h3>
            <ul className="space-y-1.5 text-sm text-slate-500">
              <li><Link href={`/${locale}/features`} className="hover:text-brand-700">{dict.nav.features}</Link></li>
              <li><Link href={`/${locale}/how-it-works`} className="hover:text-brand-700">{dict.nav.howItWorks}</Link></li>
              <li><Link href={`/${locale}/compatibility`} className="hover:text-brand-700">{dict.nav.compatibility}</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="mb-2 text-sm font-semibold text-slate-900">{dict.footer.company}</h3>
            <ul className="space-y-1.5 text-sm text-slate-500">
              <li><Link href={`/${locale}/faq`} className="hover:text-brand-700">{dict.nav.faq}</Link></li>
              <li><Link href={`/${locale}/support`} className="hover:text-brand-700">{dict.nav.support}</Link></li>
            </ul>
          </div>
        </div>
        <div className="mt-8 border-t border-slate-200 pt-6 text-xs text-slate-500">
          <p className="mb-2">{dict.footer.noticeShort}</p>
          <p>&copy; {new Date().getFullYear()} {dict.meta.siteName}. {dict.footer.rights}</p>
        </div>
      </div>
    </footer>
  );
}
