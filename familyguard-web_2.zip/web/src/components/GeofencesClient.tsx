"use client";

import { useState } from "react";
import type { Dictionary } from "@/i18n/getDictionary";

interface Geofence {
  id: string;
  name: string;
  lat: number;
  lng: number;
  radiusM: number;
  alertOnArrival: boolean;
  alertOnDeparture: boolean;
}

const emptyForm = { name: "", lat: "", lng: "", radiusM: "200", alertOnArrival: true, alertOnDeparture: true };

export default function GeofencesClient({
  initial,
  t,
}: {
  initial: Geofence[];
  t: Dictionary["dashboard"]["geofences"];
}) {
  const [geofences, setGeofences] = useState<Geofence[]>(initial);
  const [editing, setEditing] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  function startAdd() {
    setForm(emptyForm);
    setEditing(null);
    setShowForm(true);
  }

  function startEdit(g: Geofence) {
    setForm({
      name: g.name,
      lat: String(g.lat),
      lng: String(g.lng),
      radiusM: String(g.radiusM),
      alertOnArrival: g.alertOnArrival,
      alertOnDeparture: g.alertOnDeparture,
    });
    setEditing(g.id);
    setShowForm(true);
  }

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const payload = {
      name: form.name,
      lat: parseFloat(form.lat),
      lng: parseFloat(form.lng),
      radiusM: parseInt(form.radiusM, 10),
      alertOnArrival: form.alertOnArrival,
      alertOnDeparture: form.alertOnDeparture,
    };
    try {
      if (editing) {
        const res = await fetch(`/api/geofences/${editing}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        const data = await res.json();
        setGeofences((prev) => prev.map((g) => (g.id === editing ? data.geofence : g)));
      } else {
        const res = await fetch("/api/geofences", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        const data = await res.json();
        setGeofences((prev) => [...prev, data.geofence]);
      }
      setShowForm(false);
    } finally {
      setSaving(false);
    }
  }

  async function remove(id: string) {
    if (!confirm(t.confirmDelete)) return;
    await fetch(`/api/geofences/${id}`, { method: "DELETE" });
    setGeofences((prev) => prev.filter((g) => g.id !== id));
  }

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-extrabold text-slate-900">{t.title}</h1>
        <button
          onClick={startAdd}
          className="rounded-full bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700"
        >
          {t.addNew}
        </button>
      </div>

      {showForm && (
        <form onSubmit={save} className="mb-6 grid gap-3 rounded-2xl border border-slate-200 p-5 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <label className="mb-1 block text-sm font-medium text-slate-700">{t.name}</label>
            <input
              required
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium text-slate-700">{t.latitude}</label>
            <input
              required
              type="number"
              step="any"
              value={form.lat}
              onChange={(e) => setForm({ ...form, lat: e.target.value })}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium text-slate-700">{t.longitude}</label>
            <input
              required
              type="number"
              step="any"
              value={form.lng}
              onChange={(e) => setForm({ ...form, lng: e.target.value })}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium text-slate-700">{t.radius}</label>
            <input
              required
              type="number"
              min={10}
              value={form.radiusM}
              onChange={(e) => setForm({ ...form, radiusM: e.target.value })}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>
          <div className="flex items-end gap-4">
            <label className="flex items-center gap-2 text-sm text-slate-700">
              <input
                type="checkbox"
                checked={form.alertOnArrival}
                onChange={(e) => setForm({ ...form, alertOnArrival: e.target.checked })}
              />
              {t.onArrival}
            </label>
            <label className="flex items-center gap-2 text-sm text-slate-700">
              <input
                type="checkbox"
                checked={form.alertOnDeparture}
                onChange={(e) => setForm({ ...form, alertOnDeparture: e.target.checked })}
              />
              {t.onDeparture}
            </label>
          </div>
          <div className="flex gap-2 sm:col-span-2">
            <button
              type="submit"
              disabled={saving}
              className="rounded-full bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700 disabled:opacity-60"
            >
              {t.save}
            </button>
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="rounded-full border border-slate-300 px-4 py-2 text-sm font-medium text-slate-600"
            >
              {t.cancel}
            </button>
          </div>
        </form>
      )}

      {geofences.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 p-10 text-center text-slate-500">
          {t.noGeofences}
        </div>
      ) : (
        <div className="grid gap-3">
          {geofences.map((g) => (
            <div
              key={g.id}
              className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-200 p-4"
            >
              <div>
                <h3 className="font-semibold text-slate-900">{g.name}</h3>
                <p className="text-xs text-slate-500">
                  {g.lat.toFixed(4)}, {g.lng.toFixed(4)} &middot; {g.radiusM}m
                  {g.alertOnArrival ? ` · ${t.onArrival}` : ""}
                  {g.alertOnDeparture ? ` · ${t.onDeparture}` : ""}
                </p>
              </div>
              <div className="flex gap-2 text-sm font-semibold">
                <button onClick={() => startEdit(g)} className="text-brand-700 hover:underline">
                  {t.edit}
                </button>
                <button onClick={() => remove(g.id)} className="text-red-600 hover:underline">
                  {t.delete}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
