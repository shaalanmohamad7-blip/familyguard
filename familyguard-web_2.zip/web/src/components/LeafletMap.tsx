"use client";

import { MapContainer, TileLayer, Marker, Popup, Circle } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

export interface MapPoint {
  id: string;
  lat: number;
  lng: number;
  label?: string;
  popup?: string;
  variant?: "device" | "sos" | "geofence";
}

export interface MapCircle {
  id: string;
  lat: number;
  lng: number;
  radiusM: number;
  label?: string;
}

const pinColors: Record<string, string> = {
  device: "#2f83fc",
  sos: "#dc2626",
  geofence: "#059669",
};

function pinIcon(variant: string = "device") {
  const color = pinColors[variant] ?? pinColors.device;
  return L.divIcon({
    className: "",
    html: `<div style="width:20px;height:20px;border-radius:50% 50% 50% 0;background:${color};transform:rotate(-45deg);border:2px solid white;box-shadow:0 1px 4px rgba(0,0,0,0.4)"></div>`,
    iconSize: [20, 20],
    iconAnchor: [10, 20],
    popupAnchor: [0, -20],
  });
}

export default function LeafletMap({
  points,
  circles = [],
  center,
  zoom = 13,
  heightClassName = "h-[420px]",
}: {
  points: MapPoint[];
  circles?: MapCircle[];
  center: [number, number];
  zoom?: number;
  heightClassName?: string;
}) {
  return (
    <div className={`overflow-hidden rounded-xl ${heightClassName}`}>
      <MapContainer center={center} zoom={zoom} style={{ height: "100%", width: "100%" }}>
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {points.map((p) => (
          <Marker key={p.id} position={[p.lat, p.lng]} icon={pinIcon(p.variant)}>
            {p.popup && <Popup>{p.popup}</Popup>}
          </Marker>
        ))}
        {circles.map((c) => (
          <Circle
            key={c.id}
            center={[c.lat, c.lng]}
            radius={c.radiusM}
            pathOptions={{ color: "#059669", fillColor: "#059669", fillOpacity: 0.15 }}
          />
        ))}
      </MapContainer>
    </div>
  );
}
