"use client";

import { usePathname, useRouter } from "next/navigation";
import type { Locale } from "@/i18n/config";

export default function LocaleSwitcher({ locale }: { locale: Locale }) {
  const pathname = usePathname() || "/";
  const router = useRouter();

  function switchTo(next: Locale) {
    const segments = pathname.split("/");
    segments[1] = next;
    router.push(segments.join("/") || `/${next}`);
  }

  return (
    <div className="flex items-center gap-1 rounded-full border border-slate-200 bg-white p-1 text-xs font-medium">
      <button
        type="button"
        onClick={() => switchTo("en")}
        className={`rounded-full px-2.5 py-1 transition ${
          locale === "en" ? "bg-brand-600 text-white" : "text-slate-600 hover:bg-slate-100"
        }`}
      >
        EN
      </button>
      <button
        type="button"
        onClick={() => switchTo("ar")}
        className={`rounded-full px-2.5 py-1 transition ${
          locale === "ar" ? "bg-brand-600 text-white" : "text-slate-600 hover:bg-slate-100"
        }`}
      >
        عربي
      </button>
    </div>
  );
}
