"use client";

import { useEffect, useState } from "react";
import DynamicMap, { type MapPoint, type MapCircle } from "@/components/DynamicMap";
import type { Dictionary } from "@/i18n/getDictionary";
import type { Locale } from "@/i18n/config";

interface DeviceOption {
  id: string;
  label: string;
}

interface GeofenceOption {
  id: string;
  name: string;
  lat: number;
  lng: number;
  radiusM: number;
}

interface LocationRow {
  id: string;
  lat: number;
  lng: number;
  accuracyM: number;
  capturedAt: string;
  source: string;
}

const DEFAULT_CENTER: [number, number] = [24.7136, 46.6753]; // Riyadh, as a neutral default

export default function MapPageClient({
  devices,
  geofences,
  dict,
  locale,
}: {
  devices: DeviceOption[];
  geofences: GeofenceOption[];
  dict: Dictionary;
  locale: Locale;
}) {
  const t = dict.dashboard.map;
  const [selected, setSelected] = useState<string>(devices[0]?.id ?? "");
  const [locations, setLocations] = useState<LocationRow[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!selected) return;
    setLoading(true);
    fetch(`/api/devices/${selected}/locations`)
      .then((r) => (r.ok ? r.json() : { locations: [] }))
      .then((data) => setLocations(data.locations ?? []))
      .finally(() => setLoading(false));
  }, [selected]);

  const latest = locations[0];
  const points: MapPoint[] = latest
    ? [
        {
          id: latest.id,
          lat: latest.lat,
          lng: latest.lng,
          variant: latest.source === "SOS" ? "sos" : "device",
          popup: `${new Date(latest.capturedAt).toLocaleString()} · ${latest.source}`,
        },
      ]
    : [];

  const center: [number, number] = latest ? [latest.lat, latest.lng] : DEFAULT_CENTER;

  const circles: MapCircle[] = geofences.map((g) => ({
    id: g.id,
    lat: g.lat,
    lng: g.lng,
    radiusM: g.radiusM,
    label: g.name,
  }));

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-extrabold text-slate-900">{t.title}</h1>
        {devices.length > 0 && (
          <select
            value={selected}
            onChange={(e) => setSelected(e.target.value)}
            className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
          >
            {devices.map((d) => (
              <option key={d.id} value={d.id}>
                {d.label}
              </option>
            ))}
          </select>
        )}
      </div>

      {devices.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 p-10 text-center text-slate-500">
          {dict.dashboard.overview.noDevices}
        </div>
      ) : (
        <>
          <DynamicMap points={points} circles={circles} center={center} zoom={latest ? 14 : 5} />

          {!loading && !latest && (
            <p className="mt-3 text-sm text-slate-500">{t.noLocation}</p>
          )}

          <h2 className="mb-3 mt-8 text-lg font-bold text-slate-900">{t.historyTitle}</h2>
          <div className="overflow-hidden rounded-2xl border border-slate-200">
            <table className="w-full text-start text-sm">
              <thead className="bg-slate-50 text-slate-500">
                <tr>
                  <th className="px-4 py-2 text-start font-medium">{locale === "ar" ? "الوقت" : "Time"}</th>
                  <th className="px-4 py-2 text-start font-medium">{t.accuracy}</th>
                  <th className="px-4 py-2 text-start font-medium">{t.source}</th>
                </tr>
              </thead>
              <tbody>
                {locations.slice(0, 50).map((loc) => (
                  <tr key={loc.id} className="border-t border-slate-100">
                    <td className="px-4 py-2 text-slate-700">
                      {new Date(loc.capturedAt).toLocaleString()}
                    </td>
                    <td className="px-4 py-2 text-slate-500">{Math.round(loc.accuracyM)} m</td>
                    <td className="px-4 py-2 text-slate-500">{loc.source}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
