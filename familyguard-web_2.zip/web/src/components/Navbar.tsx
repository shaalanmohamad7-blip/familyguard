import Link from "next/link";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import type { Locale } from "@/i18n/config";
import type { Dictionary } from "@/i18n/getDictionary";
import LocaleSwitcher from "@/components/LocaleSwitcher";
import SignOutButton from "@/components/SignOutButton";

export default async function Navbar({
  locale,
  dict,
}: {
  locale: Locale;
  dict: Dictionary;
}) {
  const session = await getServerSession(authOptions);

  const links: [string, string][] = [
    [dict.nav.features, `/${locale}/features`],
    [dict.nav.howItWorks, `/${locale}/how-it-works`],
    [dict.nav.compatibility, `/${locale}/compatibility`],
    [dict.nav.faq, `/${locale}/faq`],
    [dict.nav.support, `/${locale}/support`],
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3">
        <Link href={`/${locale}`} className="flex items-center gap-2 font-bold text-slate-900">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-600 text-white">
            FG
          </span>
          <span>{dict.meta.siteName}</span>
        </Link>

        <nav className="hidden items-center gap-6 text-sm font-medium text-slate-600 lg:flex">
          {links.map(([label, href]) => (
            <Link key={href} href={href} className="hover:text-brand-700">
              {label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <LocaleSwitcher locale={locale} />
          {session ? (
            <>
              <Link
                href={`/${locale}/dashboard`}
                className="rounded-full bg-brand-600 px-4 py-1.5 text-sm font-semibold text-white hover:bg-brand-700"
              >
                {dict.nav.dashboard}
              </Link>
              <SignOutButton label={dict.dashboard.nav.signOut} locale={locale} />
            </>
          ) : (
            <>
              <Link
                href={`/${locale}/signin`}
                className="hidden text-sm font-semibold text-slate-700 hover:text-brand-700 sm:block"
              >
                {dict.nav.signIn}
              </Link>
              <Link
                href={`/${locale}/signup`}
                className="rounded-full bg-brand-600 px-4 py-1.5 text-sm font-semibold text-white hover:bg-brand-700"
              >
                {dict.nav.signUp}
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
