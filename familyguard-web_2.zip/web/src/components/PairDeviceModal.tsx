"use client";

import { useState } from "react";
import type { Dictionary } from "@/i18n/getDictionary";

export default function PairDeviceModal({ t }: { t: Dictionary["dashboard"]["overview"] }) {
  const [open, setOpen] = useState(false);
  const [label, setLabel] = useState("");
  const [code, setCode] = useState<string | null>(null);
  const [expiresAt, setExpiresAt] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function reset() {
    setLabel("");
    setCode(null);
    setExpiresAt(null);
    setError(null);
  }

  async function generate(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/pairing/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ deviceLabel: label }),
      });
      if (!res.ok) throw new Error("failed");
      const data = await res.json();
      setCode(data.code);
      setExpiresAt(data.expiresAt);
    } catch {
      setError("Could not generate a code. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="rounded-full bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700"
      >
        {t.pairDevice}
      </button>

      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-xl">
            <h3 className="text-lg font-bold text-slate-900">{t.pairModalTitle}</h3>

            {!code ? (
              <form onSubmit={generate} className="mt-4 space-y-4">
                <div>
                  <label className="mb-1 block text-sm font-medium text-slate-700">
                    {t.deviceLabel}
                  </label>
                  <input
                    required
                    value={label}
                    onChange={(e) => setLabel(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-brand-500 focus:outline-none"
                  />
                </div>
                {error && <p className="text-sm text-red-600">{error}</p>}
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setOpen(false);
                      reset();
                    }}
                    className="rounded-full border border-slate-300 px-4 py-2 text-sm font-medium text-slate-600"
                  >
                    {t.close}
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    className="rounded-full bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700 disabled:opacity-60"
                  >
                    {t.generateCode}
                  </button>
                </div>
              </form>
            ) : (
              <div className="mt-4">
                <p className="text-center text-4xl font-black tracking-[0.3em] text-brand-700">
                  {code}
                </p>
                {expiresAt && (
                  <p className="mt-2 text-center text-xs text-slate-500">
                    {t.codeExpires} {new Date(expiresAt).toLocaleTimeString()}
                  </p>
                )}
                <p className="mt-3 text-center text-sm text-slate-600">{t.codeInstructions}</p>
                <button
                  type="button"
                  onClick={() => {
                    setOpen(false);
                    reset();
                  }}
                  className="mt-5 w-full rounded-full border border-slate-300 px-4 py-2 text-sm font-medium text-slate-600"
                >
                  {t.close}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
