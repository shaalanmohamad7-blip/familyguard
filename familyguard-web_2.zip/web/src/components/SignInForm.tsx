"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { signIn } from "next-auth/react";
import type { Locale } from "@/i18n/config";
import type { Dictionary } from "@/i18n/getDictionary";

export default function SignInForm({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  const t = dict.auth;
  const router = useRouter();
  const searchParams = useSearchParams();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const res = await signIn("credentials", {
      email,
      password,
      redirect: false,
    });
    setLoading(false);
    if (res?.error) {
      setError(t.invalidCredentials);
      return;
    }
    const callbackUrl = searchParams.get("callbackUrl") || `/${locale}/dashboard`;
    router.push(callbackUrl);
    router.refresh();
  }

  return (
    <div className="mx-auto flex max-w-md flex-col px-4 py-16">
      <h1 className="text-2xl font-extrabold text-slate-900">{t.signInTitle}</h1>
      <p className="mt-2 text-sm text-slate-600">{t.signInSubtitle}</p>

      <form onSubmit={onSubmit} className="mt-8 space-y-4">
        <div>
          <label className="mb-1 block text-sm font-medium text-slate-700">{t.email}</label>
          <input
            required
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-brand-500 focus:outline-none"
          />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium text-slate-700">{t.password}</label>
          <input
            required
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-brand-500 focus:outline-none"
          />
        </div>

        {error && <p className="text-sm text-red-600">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-full bg-brand-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-brand-700 disabled:opacity-60"
        >
          {loading ? dict.common.loading : t.signInButton}
        </button>
      </form>

      <p className="mt-6 text-center text-sm text-slate-600">
        {t.noAccount}{" "}
        <Link href={`/${locale}/signup`} className="font-semibold text-brand-700">
          {t.createOne}
        </Link>
      </p>
      <p className="mt-4 text-center text-xs text-slate-400">
        {locale === "ar"
          ? "الحسابات الجديدة تحتاج موافقة المسؤول قبل تفعيلها."
          : "New accounts need administrator approval before they are activated."}
      </p>
    </div>
  );
}
