"use client";

import { signOut } from "next-auth/react";
import type { Locale } from "@/i18n/config";

export default function SignOutButton({
  label,
  locale,
}: {
  label: string;
  locale: Locale;
}) {
  return (
    <button
      type="button"
      onClick={() => signOut({ callbackUrl: `/${locale}` })}
      className="hidden text-sm font-semibold text-slate-500 hover:text-red-600 sm:block"
    >
      {label}
    </button>
  );
}
