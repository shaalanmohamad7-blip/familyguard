"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { signIn } from "next-auth/react";
import type { Locale } from "@/i18n/config";
import type { Dictionary } from "@/i18n/getDictionary";

export default function SignUpForm({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  const t = dict.auth;
  const router = useRouter();

  const [name, setName] = useState("");
  const [familyName, setFamilyName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [pending, setPending] = useState(false);
  const ar = locale === "ar";

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await fetch("/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, familyName, email, password }),
      });

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        if (res.status === 409) {
          setError(t.emailInUse);
        } else {
          setError(body.error || t.genericError);
        }
        setLoading(false);
        return;
      }

      const body = await res.json().catch(() => ({}));
      setLoading(false);

      // New accounts are created pending the owner's approval — don't sign in;
      // show a confirmation instead. The admin account (ACTIVE) goes straight in.
      if (body.status !== "ACTIVE") {
        setPending(true);
        return;
      }

      const signInRes = await signIn("credentials", { email, password, redirect: false });
      if (signInRes?.error) {
        router.push(`/${locale}/signin`);
        return;
      }
      router.push(`/${locale}/dashboard`);
      router.refresh();
    } catch {
      setError(t.genericError);
      setLoading(false);
    }
  }

  if (pending) {
    return (
      <div className="mx-auto max-w-md px-4 py-20 text-center">
        <div className="mx-auto mb-6 flex h-14 w-14 items-center justify-center rounded-full bg-emerald-100 text-2xl">
          ✓
        </div>
        <h1 className="text-xl font-extrabold text-slate-900">
          {ar ? "تم إنشاء حسابك" : "Your account was created"}
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-slate-600">
          {ar
            ? "حسابك الآن قيد المراجعة. سيقوم المسؤول بتفعيله قريبًا، وبعدها تقدر تسجّل الدخول وتستخدم لوحة التحكم."
            : "Your account is now under review. An administrator will activate it soon, after which you can sign in and use the dashboard."}
        </p>
        <Link
          href={`/${locale}`}
          className="mt-8 inline-block rounded-full bg-brand-600 px-5 py-2 text-sm font-semibold text-white hover:bg-brand-700"
        >
          {ar ? "العودة للرئيسية" : "Back to home"}
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto flex max-w-md flex-col px-4 py-16">
      <h1 className="text-2xl font-extrabold text-slate-900">{t.signUpTitle}</h1>
      <p className="mt-2 text-sm text-slate-600">{t.signUpSubtitle}</p>

      <form onSubmit={onSubmit} className="mt-8 space-y-4">
        <div>
          <label className="mb-1 block text-sm font-medium text-slate-700">{t.name}</label>
          <input
            required
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-brand-500 focus:outline-none"
          />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium text-slate-700">{t.familyName}</label>
          <input
            required
            type="text"
            value={familyName}
            onChange={(e) => setFamilyName(e.target.value)}
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-brand-500 focus:outline-none"
          />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium text-slate-700">{t.email}</label>
          <input
            required
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-brand-500 focus:outline-none"
          />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium text-slate-700">{t.password}</label>
          <input
            required
            minLength={8}
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-brand-500 focus:outline-none"
          />
        </div>

        {error && <p className="text-sm text-red-600">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-full bg-brand-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-brand-700 disabled:opacity-60"
        >
          {loading ? dict.common.loading : t.signUpButton}
        </button>
      </form>

      <p className="mt-6 text-center text-sm text-slate-600">
        {t.haveAccount}{" "}
        <Link href={`/${locale}/signin`} className="font-semibold text-brand-700">
          {t.signInInstead}
        </Link>
      </p>
    </div>
  );
}
