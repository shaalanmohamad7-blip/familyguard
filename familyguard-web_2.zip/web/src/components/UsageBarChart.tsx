export interface DayUsage {
  label: string;
  minutes: number;
}

export default function UsageBarChart({
  data,
  unitLabel,
}: {
  data: DayUsage[];
  unitLabel: string;
}) {
  const max = Math.max(1, ...data.map((d) => d.minutes));

  return (
    <div className="flex h-48 items-end gap-3">
      {data.map((d) => (
        <div key={d.label} className="flex flex-1 flex-col items-center gap-2">
          <div className="flex h-36 w-full items-end">
            <div
              className="w-full rounded-t-md bg-brand-500"
              style={{ height: `${(d.minutes / max) * 100}%`, minHeight: d.minutes > 0 ? 4 : 0 }}
              title={`${d.minutes} ${unitLabel}`}
            />
          </div>
          <span className="text-xs font-medium text-slate-500">{d.label}</span>
          <span className="text-[11px] text-slate-400">
            {d.minutes} {unitLabel}
          </span>
        </div>
      ))}
    </div>
  );
}
