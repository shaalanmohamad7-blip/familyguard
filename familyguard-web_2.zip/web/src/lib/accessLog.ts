import { prisma } from "@/lib/prisma";

export type ActorType = "USER" | "DEVICE";

/**
 * Records a mutating action against a family's audit trail. Never throws —
 * a logging failure must never block the underlying request.
 */
export async function logAccess(params: {
  familyId: string;
  actorType: ActorType;
  actorId: string;
  action: string;
  targetType?: string;
  targetId?: string;
}): Promise<void> {
  try {
    await prisma.accessLog.create({
      data: {
        familyId: params.familyId,
        actorType: params.actorType,
        actorId: params.actorId,
        action: params.action,
        targetType: params.targetType,
        targetId: params.targetId,
      },
    });
  } catch (err) {
    console.error("Failed to write access log", err);
  }
}
