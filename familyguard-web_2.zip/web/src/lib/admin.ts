import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

/** The platform owner's email, set via the ADMIN_EMAIL environment variable. */
export function adminEmail(): string | null {
  const e = process.env.ADMIN_EMAIL?.toLowerCase().trim();
  return e || null;
}

/** True when the given email is the platform owner (admin). */
export function isAdminEmail(email?: string | null): boolean {
  const admin = adminEmail();
  const e = email?.toLowerCase().trim();
  return !!admin && !!e && admin === e;
}

/** True when the current signed-in session belongs to the platform owner. */
export async function isAdminSession(): Promise<boolean> {
  const session = await getServerSession(authOptions);
  return isAdminEmail(session?.user?.email);
}
