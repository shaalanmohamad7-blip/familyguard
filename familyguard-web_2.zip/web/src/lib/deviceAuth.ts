import jwt from "jsonwebtoken";

export interface DeviceTokenClaims {
  deviceId: string;
  familyId: string;
  type: "device";
}

function getSecret(): string {
  const secret = process.env.DEVICE_JWT_SECRET;
  if (!secret) {
    throw new Error("DEVICE_JWT_SECRET is not configured");
  }
  return secret;
}

/** Mint a device token. Only ever called from the pairing-redeem route. */
export function signDeviceToken(claims: Omit<DeviceTokenClaims, "type">): string {
  const payload: DeviceTokenClaims = { ...claims, type: "device" };
  return jwt.sign(payload, getSecret(), { expiresIn: "365d" });
}

/** Verify a device token, returning its claims or null if invalid/expired/wrong-type. */
export function verifyDeviceToken(token: string): DeviceTokenClaims | null {
  try {
    const decoded = jwt.verify(token, getSecret());
    if (
      typeof decoded === "object" &&
      decoded !== null &&
      (decoded as Record<string, unknown>).type === "device" &&
      typeof (decoded as Record<string, unknown>).deviceId === "string" &&
      typeof (decoded as Record<string, unknown>).familyId === "string"
    ) {
      return decoded as unknown as DeviceTokenClaims;
    }
    return null;
  } catch {
    return null;
  }
}

/** Extracts and verifies the Bearer device token from an incoming Request. */
export function authenticateDevice(req: Request): DeviceTokenClaims | null {
  const header = req.headers.get("authorization") || req.headers.get("Authorization");
  if (!header || !header.startsWith("Bearer ")) return null;
  const token = header.slice("Bearer ".length).trim();
  if (!token) return null;
  return verifyDeviceToken(token);
}
