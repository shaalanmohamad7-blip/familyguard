import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export interface ParentContext {
  userId: string;
  familyId: string;
  role: "PARENT" | "GUARDIAN";
}

/**
 * Resolves the signed-in parent's session and their family membership.
 * Returns null when there is no session or the user belongs to no family —
 * callers must respond 401/403 rather than trust any familyId from the client.
 */
export async function requireParentContext(): Promise<ParentContext | null> {
  const session = await getServerSession(authOptions);
  const userId = session?.user?.id;
  if (!userId) return null;

  const membership = await prisma.familyMember.findFirst({
    where: { userId },
    orderBy: { id: "asc" },
  });
  if (!membership) return null;

  return {
    userId,
    familyId: membership.familyId,
    role: membership.role,
  };
}

/** Confirms a device belongs to the given family. Returns the device or null. */
export async function getFamilyDevice(familyId: string, deviceId: string) {
  return prisma.device.findFirst({ where: { id: deviceId, familyId } });
}
