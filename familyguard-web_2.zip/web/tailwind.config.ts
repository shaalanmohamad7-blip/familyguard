import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#eef6ff",
          100: "#d9ebff",
          200: "#bcdcff",
          300: "#8ec5ff",
          400: "#59a5ff",
          500: "#2f83fc",
          600: "#1c63e8",
          700: "#174ec2",
          800: "#18429b",
          900: "#193a7a",
        },
      },
    },
  },
  plugins: [],
};

export default config;
